// импорт модели
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { NODE_ENV, JWT_SECRET } = process.env;

module.exports.createUser = (req, res) => {
  const { name, about, avatar, password, email } = req.body;
  bcrypt.hash(password, 10)
    .then(hash => User.create({ name, about, avatar, email, password: hash }))
    .then(user => res.send({ data: user }))
    .catch(() => res.status(400).send({ message: 'Ошибка при создании пользователя' }));
};


module.exports.findUser = (req, res) => {
  User.findById(req.params.id)
    .then((user) => {
      if (!user) throw ({ message: "Пользователь не найден" });
      return user;
    })
    .then((user) => res.send(user))
    .catch(() => res.status(404).send({ message: "Пользователь не найден" }));
}


module.exports.getUsers = (req, res) => {
  User.find({})
    .then(user => res.send({ data: user }))
    .catch(() => res.status(500).send({ message: 'Не удается получить список пользователей' }));
};


module.exports.login = (req, res) => {
  const { email, password } = req.body;



  User.findOne({ email }).select('+password')
    .then((user) => {
      if (!user) {
        return Promise.reject(res.send({ "message": "Неверные учетные данные" }));
      }

      return bcrypt.compare(password, user.password);
    })
    .then((matched) => {
      if (!matched) {
        return Promise.reject(res.send({ "message": "Неверные учетные данные" }));
      }
      return User.findUserByCredentials(email, password)
        .then((user) => {
          const token = jwt.sign({ _id: user._id }, NODE_ENV === 'production' ? JWT_SECRET : 'dev-secret', { expiresIn: "7d" });
          res.send({ token }, ({ "message": "Пользователь авторизован" }));
        })
        .catch(() => {
          res.status(401).send({ "message": "Ошибка авторизации" });
        });
    })
    .catch(() => {
      res.status(401).send({ "message": "Данный пользователь не найден" })
    });
};